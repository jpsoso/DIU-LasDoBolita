# DIU - Practica 3, entregables

## Moodboard (diseño visual + logotipo)   


## Landing Page


## Mockup: LAYOUT HI-FI


## Documentación: Publicación del Case Study


(incluye) Valoración del equipo sobre la realización de esta práctica o los problemas surgidos
 
